using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TransScene : MonoBehaviour
{
    void InputName()
    {
        SceneManager.LoadScene("InputName");
    }
}
